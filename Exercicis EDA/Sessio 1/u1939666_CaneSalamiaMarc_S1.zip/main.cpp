//Marc Can� Salami�
//u1939666
//Pr�ctica 1
#include <iostream>
#include "Pokedex.h"

using namespace std;

int main()
{
    Pokedex poke;
    poke.Llegir_Pokemons();
    poke.Mostrar_Pokemons();
    return 0;
}
