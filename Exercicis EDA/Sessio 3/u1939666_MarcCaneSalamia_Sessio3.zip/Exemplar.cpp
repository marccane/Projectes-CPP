#include "Exemplar.h"

Exemplar::Exemplar()
{
    //ctor
}

void Exemplar::mostrar(){
    cout<<a_alias<<endl<<a_nomPokemon<<endl<<a_poder<<endl;
}

void Exemplar::Setter(string alias, string nompok, float poder){
    a_alias=alias;
    a_nomPokemon=nompok;
    a_poder=poder;
}

bool operator<(Exemplar e, Exemplar e1){
    return e.a_alias<e1.a_alias;
}
