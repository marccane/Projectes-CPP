//Marc Can� Salami�
//u1939666
//Sessi� 2
#ifndef USUARI_H
#define USUARI_H
#include <iostream>
#include <set>
#include "Exemplar.h"
using namespace std;
class Usuari
{
    public:
        Usuari();
        bool EsFi()const;
        string Get_Nom();
        bool TePokemonX(string pok);
        void Netejar_List();

    private:
        string a_alias, a_adreca;
        set<Exemplar> a_pokemons;

        friend ostream& operator<<(ostream &o, Usuari u);
        friend istream& operator>>(istream &o, Usuari &u);
};

#endif // USUARI_H
