//Marc Can� Salami�
//u1939666
//Sessi� 2
#include <iostream>
#include "Joc.h"

using namespace std;

int main()
{
    Joc joc;
    cin>>joc;
    cout<<joc;
    return 0;
}
