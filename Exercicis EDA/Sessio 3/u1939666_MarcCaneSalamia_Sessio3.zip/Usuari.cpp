//Marc Can� Salami�
//u1939666
//Sessi� 2
#include "Usuari.h"
#include <iostream>
using namespace std;
Usuari::Usuari()
{
    //ctor
}

bool Usuari::EsFi()const{
    return a_alias=="*";
}

string Usuari::Get_Nom(){
    return a_alias;
}

void Usuari::Netejar_List(){
    a_pokemons.clear();
}

bool Usuari::TePokemonX(string pok){
   /* bool res=false;
    for (set<Exemplar>::iterator it = a_pokemons.begin(); it != a_pokemons.end(); it++)
        if(*it==pok)res=true;
    return res;*/
}

ostream& operator<<(ostream &o, Usuari u){
    o<<u.a_alias<<" ["<<u.a_adreca<<"]"<<endl;
    for (set<Exemplar>::iterator it = u.a_pokemons.begin(); it != u.a_pokemons.end(); it++)
        //it->mostrar();
    return o;
}

istream& operator>>(istream &o, Usuari &u){
    string temp, temp2;
    float temp3;
    Exemplar texem;
    o>>u.a_alias;
    if(u.a_alias!="*"){
        o>>u.a_adreca;
        getline(o,temp);
        while(temp!="*"){
            getline(o,temp2);
            o>>temp3;
            texem.Setter(temp,temp2,temp3);
            u.a_pokemons.insert(texem);
            getline(o,temp);
        }
    }
    return o;
}
