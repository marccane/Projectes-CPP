#ifndef EXEMPLAR_H
#define EXEMPLAR_H
#include <iostream>
using namespace std;

class Exemplar
{
    public:
        Exemplar();
        void Setter(string alias, string nompok, float poder);
        void mostrar();
        friend bool operator<(Exemplar,Exemplar);
    protected:

    private:
        string a_alias, a_nomPokemon;
        float a_poder;
};

#endif // EXEMPLAR_H
