#include <iostream>
#include <fstream>

using namespace std;

const int MIDA_MAXIMA=25+4;

struct jugador{};

void Netejar_Taula(char taula[][MIDA_MAXIMA]){
    for(int i=0;i<columnes;i++){
        for(int j=0;j<files;j++){
            taula[j][i]=' ';
        }
    }
}

void Fer_Contorn(int files, int columnes, char taula[][MIDA_MAXIMA]){
    char lletra='a', lletra2='a';
    for(int i=2;i<columnes-2;i++){
        taula[0][i]=lletra;
        lletra++;
    }
    for(int i=2;i<files-2;i++){
        taula[i][0]=lletra2;
        lletra2++;
    }
}

void Escriure_Taula(int files, int columnes, char taula[][MIDA_MAXIMA]){
    for(int i=0;i<columnes;i++){
        for(int j=0;j<files;j++){
            cout<<taula[j][i];
        }
        cout<<endl;
    }
}

int main()
{
    int files, columnes, temp, filactual=0, columnactual=3, nombrejugadors;
    bool esmur;
    char taula[MIDA_MAXIMA][MIDA_MAXIMA];
    string nomarxiu="tauler4x4.txt";
    fstream fitxer;

    fitxer.open(nomarxiu.c_str(),fstream::in);
    if (!fitxer.is_open()){
    cout << "NO S'HA TROBAT EL FITXER" << endl;
    return 1;
    }

    Netejar_Taula(taula);
    Fer_Contorn(files,columnes,taula);
    //cin>>nombrejugadors;
    nombrejugadors=4;
    fitxer>>files>>columnes;
    Fer_Contorn(files, columnes, nombrejugadors, taula);
    while(!fitxer.eof()){
        fitxer>>temp;
        for(int i=0;i<temp;i++){
            if(columnactual-3<columnes){
                if(esmur)taula[filactual][columnactual]=' ';
                else taula[filactual][columnactual]='#';
                columnactual++;
            }
            else{
                columnactual++;
                filactual=3;
            }
        }
        esmur=!esmur;
    }
    Escriure_Taula(files, columnes, taula);
    return 0;
}
