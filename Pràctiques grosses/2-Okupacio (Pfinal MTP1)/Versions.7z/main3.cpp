#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

const int MIDA_MAXIMA=25+4, AMPLADA=13, JUGADORS_MAX=10+1;

//typedef

struct Jugador{
    int caselles, arrabassades, sense_tirar;
    char lletra;
    bool actiu;
};

void Inicialitzar_Tupla(Jugador Jugadors[]){
    for(int i=1;i<JUGADORS_MAX;i++){
        Jugadors[i].sense_tirar=i-1;
        Jugadors[i].caselles=0;
        Jugadors[i].arrabassades=0;
        Jugadors[i].actiu=true;
    }
}

void Netejar_tauler(char tauler[][MIDA_MAXIMA]){
    for(int i=0;i<MIDA_MAXIMA;i++){
        for(int j=0;j<MIDA_MAXIMA;j++){
            tauler[j][i]=' ';
        }
    }
}

void Fer_Contorn(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    char lletra='a', lletra2='a';
    for(int i=2;i<columnes+2;i++){//lletres verticals
        tauler[0][i]=lletra;
        lletra++;
    }
    for(int i=2;i<files+2;i++){
        tauler[i][0]=lletra2;
        lletra2++;
    }
    for(int i=1;i<columnes+4;i++){
        tauler[1][i]='#';
        tauler[2+files][i]='#';
    }
    for(int i=1;i<files+4;i++){
        tauler[i][1]='#';
        tauler[i][2+columnes]='#';
    }
}

void Posar_Murs(int columnes, fstream &fitxer, char tauler[][MIDA_MAXIMA]){
    int temp, columnactual=2, filactual=2;
    bool esmur=false;
    while(!fitxer.eof()){
        fitxer>>temp;
            for(int i=0;i<temp;i++){
                if(esmur)tauler[columnactual][filactual]='#';
                if(columnactual-1==columnes){
                    filactual++;
                    columnactual=2;
                }
                else columnactual++;
            }
        esmur=!esmur;
    }
}

void Dibuixar_Tauler(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    cout<<endl;
    for(int i=0;i<columnes+3;i++){
        for(int j=0;j<files+3;j++){
            cout<<tauler[j][i];
        }
        cout<<endl;
    }
    cout<<endl;
}

int Jugadors_Actius(Jugador Jugadors[], int nombrejugadors){
    int actius=0;
    for(int i=1;i<=nombrejugadors;i++){
        if(Jugadors[i].actiu)actius++;
    }
    return actius;
}

bool EsPle(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    bool trobat=false; //espai
    int i=2,j;
    while(i<columnes+2 and !trobat){
        j=2;
        while(j<files+2 and !trobat){
            if(tauler[i][j]==' ')trobat=true; //i i j est�n correctes?
            j++;
        }
        i++;
    }
    return !trobat;
}

int Buscar_Proper_Torn(int jugadors_totals, int torn, Jugador Jugadors[]){
    int Proper_Jugador=-1;
    bool trobat=false;
    while(!trobat){
        if(torn+1<=jugadors_totals){
            torn++;
            if(Jugadors[torn].actiu){
                trobat=true;
                Proper_Jugador=torn;
            }
        }
        else torn=0; //Aix� funciona b�
    }
    return Proper_Jugador;
}

void Actualitzar_Temps(int torn, int jugadors_totals, Jugador Jugadors[]){
    for(int i=1;i<=jugadors_totals;i++){
        Jugadors[i].sense_tirar++;
    }
    Jugadors[torn].sense_tirar=0;
}

void Esborrar_Exercit(int files, int columnes, int exercit, char tauler[][MIDA_MAXIMA]){
    for(int i=2;i<columnes+2;i++){
        for(int j=2;j<files+2;j++){
            if(tauler[i][j]==exercit)tauler[i][j]=' ';
        }
    }
}

bool Comparar(int j, Jugador temp[], int mode){
    bool resultat;
    switch(mode){
    case 1:
        resultat=temp[j].arrabassades>temp[j-1].arrabassades;
        break;
    case 2:
        resultat=temp[j].caselles>temp[j-1].caselles;
        break;
    case 3:
        resultat=temp[j].sense_tirar>temp[j-1].sense_tirar; // SIGNE!!
        break;
    }
    return resultat;
}

void Intercanviar(Jugador &a, Jugador &b){
    Jugador aux=a;
    b=a;
    a=aux;
}

void Ordenar_Ranking(int nombrejugadors, const Jugador Jugadors[], Jugador temp[]){
    for(int i=0;i<=nombrejugadors+1;i++)
        temp[i]=Jugadors[i];
    for(int i=1;i<nombrejugadors;i++){
        for(int j=nombrejugadors;j>i;j--){
            if(Comparar(j,temp,1))
                Intercanviar(temp[j],temp[j-1]);
                //!FALTEN DUES CONDICIONS
            //else if(Comparar(estats,j,10+mode)){
            //    if(estats[j].nom<estats[j-1].nom) Intercanviar(estats[j],estats[j-1]);
          //  }
        }
    }
}

void Escriure_Ranking(int nombrejugadors, Jugador Jugadors[]){
    Jugador temp[MIDA_MAXIMA];
    const string dades[]={"JUGADOR","CASELLES","ARRABASSADES","SENSE TIRAR"};
    Ordenar_Ranking(nombrejugadors,Jugadors,temp);
    for(int i=0;i<4;i++){
        cout<<right<<setw(AMPLADA)<<dades[i];
    }
    cout<<endl;
    for(int i=1;i<=nombrejugadors;i++){
        if(temp[i].actiu){
            cout<<right<<setw(AMPLADA)<<temp[i].lletra;
            cout<<right<<setw(AMPLADA)<<temp[i].caselles;
            cout<<right<<setw(AMPLADA)<<temp[i].arrabassades;
            cout<<right<<setw(AMPLADA)<<temp[i].sense_tirar<<endl;
        }
    }
    cout<<endl;
}

void Assignar_Lletres(int numjugadors, Jugador Jugadors[]){
    for(int i=1;i<=numjugadors;i++){
        Jugadors[i].lletra=i+'A'-1;
    }
}

//void Control_Files

void Pos_Orientacio(int fila, int columna, int &fila_transf, int &col_transf, int orientacio){ //Posicio en funci� de l'orientaci�
    fila_transf=fila;
    col_transf=columna;
    if(orientacio==0)fila_transf--;
    if(orientacio==1)col_transf--;
    if(orientacio==2)fila_transf++;
    if(orientacio==3)col_transf++;
}

void Buscar_Adjacents(int fila, int columna, int &caselles_adj, int adj_orientacio[], char tauler[][MIDA_MAXIMA]){
    int pos=0;
    for(int i=0;i<5;i++)
        adj_orientacio[i]=-1;
    if(tauler[columna][fila-1]!='#'){
        adj_orientacio[pos]=0;
        pos++;
    }
    if(tauler[columna-1][fila]!='#'){
        adj_orientacio[pos]=1;
        pos++;
    }
    if(tauler[columna][fila+1]!='#'){
        adj_orientacio[pos]=2;
        pos++;
    }
    if(tauler[columna+1][fila]!='#'){
        adj_orientacio[pos]=3;
        pos++;
    }
    for(int i=0;i<=3;i++)
        if(adj_orientacio[i]!=-1)caselles_adj++;
}

void Tractar_Adjacents(int fila, int columna, Jugador Jug[], int torn, char tauler[][MIDA_MAXIMA]){
    int adj_prim=0,adj_sec,f_sec,c_sec,f_ter,c_ter; //Posicions adjacent prim�ria secund�ria terciaria
    int adj_prim_orientacio[5],adj_sec_orientacio[5];
    Buscar_Adjacents(fila,columna,adj_prim,adj_prim_orientacio,tauler);
    //cout<<"adj prim = "<<adj_prim<<endl;
    for(int i=0;i<adj_prim;i++){
        adj_sec=0;
        Pos_Orientacio(fila,columna,f_sec,c_sec,adj_prim_orientacio[i]);
        //La posiciod e la casella sencundaria �s f_sec i c_sec
        //Mirar quantes adjacents t� AQUESTA adjacent //si les adjacents duna adjacent s�n 1, okupar
        Buscar_Adjacents(f_sec,c_sec,adj_sec,adj_sec_orientacio,tauler); //Busquem les adjacents de la casella secund�ria
        switch(adj_sec){
        case 1:
            if(tauler[c_sec][f_sec]==' '){
                tauler[c_sec][f_sec]=Jug[torn].lletra;
                Jug[torn].caselles++;
            }
            break;
        case 2:
            char Lletra1;
            Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[0]);
            Lletra1=tauler[c_ter][f_ter];
            Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[1]);
            if(Lletra1==tauler[c_ter][f_ter] and Lletra1==Jug[torn].lletra){
                if(tauler[c_sec][f_sec]!=' '){
                    Jug[tauler[c_sec][f_sec]-'A'+1].caselles--;
                    Jug[torn].arrabassades++;
                }
                tauler[c_sec][f_sec]=Jug[torn].lletra;
                Jug[torn].caselles++;
            }
            break;
        case 3:

            break;
        case 4:
            break;
        }
    }
}

int main()
{
    int files, columnes, nombrejugadors=0, torn=1;
    Jugador Jugadors[11];
    char tauler[MIDA_MAXIMA][MIDA_MAXIMA], exercit_mayus, fila, columna;
    string nomarxiu="tauler4x4.txt";
    fstream fitxer;

    fitxer.open(nomarxiu.c_str(),fstream::in);
    if (!fitxer.is_open()){
        cout << "NO ES POT OBRIR EL FITXER" << endl;
        return 1;
    }
    else{
        cout<<"BENVINGUTS A OKUPACIO !"<<endl<<"ENTRA NOMBRE DE JUGADORS (2..10):"<<endl;
        //nombrejugadors=3;
        while(nombrejugadors<2 or nombrejugadors>10)
            cin>>nombrejugadors;
        cout<<"NOM DEL FITXER DEL TAULER:"<<endl;
        //cin>>nomarxiu;

        fitxer>>files>>columnes;
        Netejar_tauler(tauler);
        Inicialitzar_Tupla(Jugadors);
        Fer_Contorn(files,columnes,tauler);
        Posar_Murs(columnes,fitxer,tauler);
        Dibuixar_Tauler(files,columnes,tauler);
        Assignar_Lletres(nombrejugadors,Jugadors);
        while(!EsPle(files,columnes,tauler) and torn!=-1){
            exercit_mayus=torn+'A'-1;
            cout<<"JUGADOR "<<exercit_mayus<<endl;
            cin>>fila>>columna;
            if((fila<'a' or fila>nombrejugadors))
            if(fila=='0' and columna=='0'){
                Jugadors[torn].actiu=false; //Vigilar l'ordre!
                Esborrar_Exercit(files,columnes,exercit_mayus,tauler);
            }
            fila=fila-'a'+2; columna=columna-'a'+2;
            if(tauler[columna][fila]==' '){
                tauler[columna][fila]=exercit_mayus;
                Jugadors[torn].caselles++;
            }
            Tractar_Adjacents(fila,columna,Jugadors,torn,tauler);
            Actualitzar_Temps(torn,nombrejugadors,Jugadors);
            Dibuixar_Tauler(files,columnes,tauler);
            Escriure_Ranking(nombrejugadors,Jugadors);
            if(Jugadors_Actius(Jugadors,nombrejugadors)>1)
                torn=Buscar_Proper_Torn(nombrejugadors,torn,Jugadors);
            else torn=-1;
        }
        cout<<"GAME OVER"<<endl<<endl;
    //if(Jugadors_Actius(Jugadors,nombrejugadors)==1)
    }
    cout<<"Aix� �s una mesura anti-acme"<<endl;
    return 0;
}
