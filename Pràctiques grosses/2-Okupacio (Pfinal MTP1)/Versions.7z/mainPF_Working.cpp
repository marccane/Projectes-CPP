#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

const int MIDA_MAXIMA=25+4, AMPLADA=13, JUGADORS_MAX=10+1;

//typedef VectorJugador

struct Jugador{
    int caselles, arrabassades, sense_tirar;
    char lletra;
    bool actiu;
};

struct Tauler{
    char mapa[MIDA_MAXIMA][MIDA_MAXIMA];
};

void Inicialitzar_Tupla(int jugadors, Jugador Jugadors[]){
    //Pre: -
    //Post: La tupla de jugadors correctament inicialitzada
    for(int i=1;i<JUGADORS_MAX;i++){
        Jugadors[i].sense_tirar=jugadors-i;
        Jugadors[i].caselles=0;
        Jugadors[i].arrabassades=0;
        Jugadors[i].lletra=i+'A'-1;
        Jugadors[i].actiu=true;
    }
}

void Netejar_tauler(char tauler[][MIDA_MAXIMA]){
    //Pre: -
    //Post: El tauler de car�ctesrs inicialitzar amb espais
    for(int i=0;i<MIDA_MAXIMA;i++){
        for(int j=0;j<MIDA_MAXIMA;j++){
            tauler[j][i]=' ';
        }
    }
}

void Fer_Contorn(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    //Pre: files>3 i columnes >3
    //Post:El tauler amb el contorn corresponent
    char lletra='a', lletra2='a';
    for(int i=2;i<files+2;i++){//lletres verticals
        tauler[0][i]=lletra;
        lletra++;
    }
    for(int i=2;i<columnes+2;i++){
        tauler[i][0]=lletra2;
        lletra2++;
    }
    for(int i=1;i<columnes+3;i++){//fer files
        tauler[i][1]='#';
        tauler[i][files+2]='#';
    }
    for(int i=1;i<files+3;i++){//fer columnes
        tauler[1][i]='#';
        tauler[columnes+2][i]='#';
    }
}

void Posar_Murs(int columnes, fstream &fitxer, char tauler[][MIDA_MAXIMA]){
    //Pre: L'arxiu obert i columnes>3
    //Post: El tauler amb els murs colocats correctament
    int temp, columnactual=2, filactual=2;
    bool esmur=false;
    while(!fitxer.eof()){
        fitxer>>temp;
            for(int i=0;i<temp;i++){
                if(esmur)tauler[columnactual][filactual]='#';
                if(columnactual-1==columnes){
                    filactual++;
                    columnactual=2;
                }
                else columnactual++;
            }
        esmur=!esmur;
    }
}

void Dibuixar_Tauler(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    //Pre: files>3 i columnes>3
    //Post: Dibuixa en pantalla la taula de caracters
    cout<<endl;
    for(int i=0;i<files+3;i++){
        for(int j=0;j<columnes+4;j++){
            cout<<tauler[j][i];
        }
        cout<<endl;
    }
    cout<<endl;
}

int Jugadors_Actius(Jugador Jugadors[], int nombrejugadors){
    //Pre: -
    //Post: El numero de jugadors actius
    int actius=0;
    for(int i=1;i<=nombrejugadors;i++){
        if(Jugadors[i].actiu)actius++;
    }
    return actius;
}

bool EsPle(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    //Pre: -
    //Post: Un bole� que es verdader si tot el tauler de joc �s ple
    bool trobat=false; //espai
    int i=2,j;
    while(i<columnes+2 and !trobat){
        j=2;
        while(j<files+2 and !trobat){
            if(tauler[i][j]==' ')trobat=true;
            j++;
        }
        i++;
    }
    return !trobat;
}

int Buscar_Proper_Torn(int jugadors_totals, int torn, Jugador Jugadors[]){
    //Pre: -
    //Post: El torn del proper jugador
    int Proper_Jugador=-1;
    bool trobat=false;
    while(!trobat){
        if(torn+1<=jugadors_totals){
            torn++;
            if(Jugadors[torn].actiu){
                trobat=true;
                Proper_Jugador=torn;
            }
        }
        else torn=0; //Aix� funciona b�
    }
    return Proper_Jugador;
}

void Actualitzar_Temps(int torn, int jugadors_totals, Jugador Jugadors[]){
    //Pre: Torn del jugador actual
    //Post: El torn del proper jugador
    for(int i=1;i<=jugadors_totals;i++){
        Jugadors[i].sense_tirar++;
    }
    Jugadors[torn].sense_tirar=0;
}

void Esborrar_Exercit(int files, int columnes, int exercit, char tauler[][MIDA_MAXIMA]){
    //Pre: Una lletra de l'equip del qual s'han desborrar els exercits
    //Post: El tauler sense els exercits dels jugadors retirats
    for(int i=2;i<columnes+2;i++){
        for(int j=2;j<files+2;j++){
            if(tauler[i][j]==exercit)tauler[i][j]=' ';
        }
    }
}

void Intercanviar(Jugador &a, Jugador &b){
    //Pre: -
    //Post: Els jugadors intercanviats
    Jugador aux=a;
    a=b;
    b=aux;
}

void Ordenar_Ranking(int nombrejugadors, const Jugador Jugadors[], Jugador temp[]){
    //Pre: -
    //Post: Ordena el vector de jugadors temporal
    for(int i=0;i<=nombrejugadors+1;i++)
        temp[i]=Jugadors[i];
    for(int i=1;i<nombrejugadors;i++){
        for(int j=nombrejugadors;j>i;j--){
            if(temp[j].caselles>temp[j-1].caselles)
                Intercanviar(temp[j],temp[j-1]);
            else if(temp[j].caselles==temp[j-1].caselles){
                if(temp[j].arrabassades>temp[j-1].arrabassades)
                    Intercanviar(temp[j],temp[j-1]);
                else if(temp[j].arrabassades==temp[j-1].arrabassades){
                     if(temp[j].sense_tirar>temp[j-1].sense_tirar)
                        Intercanviar(temp[j],temp[j-1]);
                }
            }
        }
    }
}

void Escriure_Ranking(int nombrejugadors, Jugador Jugadors[]){
    //Pre: -
    //Post: Escriu en pantalla el ranking dels jugadors
    Jugador temp[MIDA_MAXIMA];
    const string dades[]={"JUGADOR","CASELLES","ARRABASSADES","SENSE TIRAR"};
    Ordenar_Ranking(nombrejugadors,Jugadors,temp);
    for(int i=0;i<4;i++){
        cout<<right<<setw(AMPLADA)<<dades[i];
    }
    cout<<endl;
    for(int i=1;i<=nombrejugadors;i++){
        if(temp[i].actiu){
            cout<<right<<setw(AMPLADA)<<temp[i].lletra;
            cout<<right<<setw(AMPLADA)<<temp[i].caselles;
            cout<<right<<setw(AMPLADA)<<temp[i].arrabassades;
            cout<<right<<setw(AMPLADA)<<temp[i].sense_tirar<<endl;
        }
    }
    cout<<endl;
}

void Pos_Orientacio(int fila, int columna, int &fila_transf, int &col_transf, int orientacio){
    //Pre: -
    //Post: Dona la posici� de la casella que es troba en la orientaci� entrada respecte al punt original
    fila_transf=fila;
    col_transf=columna;
    if(orientacio==0)fila_transf--;
    if(orientacio==1)col_transf--;
    if(orientacio==2)fila_transf++;
    if(orientacio==3)col_transf++;
}

void Buscar_Adjacents(int fila, int columna, int &caselles_adj, int adj_orientacio[], char tauler[][MIDA_MAXIMA]){
    //Pre: -
    //Post: El numero de caselles adjacents i un vector amb les orientacions d'aquestes
    int pos=0;
    for(int i=0;i<5;i++)
        adj_orientacio[i]=-1;
    if(tauler[columna][fila-1]!='#'){
        adj_orientacio[pos]=0;
        pos++;
    }
    if(tauler[columna-1][fila]!='#'){
        adj_orientacio[pos]=1;
        pos++;
    }
    if(tauler[columna][fila+1]!='#'){
        adj_orientacio[pos]=2;
        pos++;
    }
    if(tauler[columna+1][fila]!='#'){
        adj_orientacio[pos]=3;
        pos++;
    }
    for(int i=0;i<=3;i++)
        if(adj_orientacio[i]!=-1)caselles_adj++;
}

void Arrabassar_General(int fila, int col, Jugador Jug[], int torn, char tauler[][MIDA_MAXIMA]){
    if(tauler[col][fila]==' '){
        tauler[col][fila]=Jug[torn].lletra;
        Jug[torn].caselles++;
    }
    else if(tauler[col][fila]!=Jug[torn].lletra and tauler[col][fila]!=' '){//si no �s del que te el torn i no �s buida
        Jug[tauler[col][fila]-'A'+1].caselles--;
        Jug[torn].arrabassades++;
        tauler[col][fila]=Jug[torn].lletra;
        Jug[torn].caselles++;
    }
}

void Tractar_Adjacents(int fila, int columna, Jugador Jug[], int torn, char tauler[][MIDA_MAXIMA]){
    //Pre: -
    //Post: El tauler amb les caselles adjacents conquerides seguitn les normes del joc
    int adj_prim=0,adj_sec,f_sec,c_sec,c_ter,f_ter,temp=0,temp2;
    int adj_prim_orientacio[5],adj_sec_orientacio[5];
    char lletres[6],lletra1;
    Buscar_Adjacents(fila,columna,adj_prim,adj_prim_orientacio,tauler);
    for(int i=0;i<adj_prim;i++){
        adj_sec=0; temp=0;
        Pos_Orientacio(fila,columna,f_sec,c_sec,adj_prim_orientacio[i]);
        Buscar_Adjacents(f_sec,c_sec,adj_sec,adj_sec_orientacio,tauler);
        //cout<<"La adjacent "<<i<<" te "<<adj_sec<<" adjacents. Posicio de la casella a la que estem buscant adjacents:"<<f_sec<<" "<<c_sec<<endl;
        switch(adj_sec){
        case 1:
            Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
            break;
        case 2:
            Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[0]);
            lletra1=tauler[c_ter][f_ter];
            Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[1]);
            if(lletra1==tauler[c_ter][f_ter] and lletra1==Jug[torn].lletra){
                Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
            }
            break;
        case 3:
            for(int j=0;j<adj_sec;j++){
                Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[j]);
                lletres[j]=tauler[c_ter][f_ter];
                if(lletres[j]==Jug[torn].lletra)temp++;
                //cout<<"lletra "<<j<<" "<<lletres[j]<<endl;
                }
            //cout<<"Dins cas 3: "<<"temp="<<temp<<endl;
            //cout<<"Informacio sobre les adjacents: "<<" 0:"<<lletres[0]<<" 1:"<<lletres[1]<<" 2:"<<lletres[2]<<" 3:"<<lletres[3]<<endl;
            if(lletres[0]==lletres[1] and lletres[1]==lletres[2]){
                Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
                //cout<<"Cas 3 mode 1"<<endl;
            }
            else if(temp==2 and tauler[c_sec][f_sec]==' '){
                    Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
                    //cout<<"Cas 3 mode 2"<<endl;
            }
            break;
        case 4:
            for(int j=0;j<adj_sec;j++){
                Pos_Orientacio(f_sec,c_sec,f_ter,c_ter,adj_sec_orientacio[j]);
                lletres[j]=tauler[c_ter][f_ter];
                if(Jug[torn].lletra==lletres[j])temp++;
                else temp2=j;
            }
            if(temp==4){
                Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
            }
            if(temp==3){
                if(tauler[c_sec][f_sec]==' '){
                    Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
                }
                else if(lletres[temp2]!=tauler[c_sec][f_sec]){
                    Arrabassar_General(f_sec,c_sec,Jug,torn,tauler);
                    /*Jug[tauler[c_sec][f_sec]-'A'+1].caselles--;
                    tauler[c_sec][f_sec]=Jug[torn].lletra;
                    Jug[torn].arrabassades++;
                    Jug[torn].caselles++;*/
                }
            }
            break;
        }
    }
}

bool Entrada_Correcta(int fila, int columna, int files, int columnes, char tauler[][MIDA_MAXIMA]){
    bool escorrecte=false;
    int fila_mod=fila-'a'+2, columna_mod=columna-'a'+2;
    if(fila>='a' and fila-'a'+1<=files)
        if(columna>='a' and columna-'a'+1<=columnes)
            if(tauler[columna_mod][fila_mod]==' ')
                escorrecte=true;
    if(fila=='0' and columna=='0')
        escorrecte=true;
   return escorrecte;
}

void Escriure_Guanyador(int nombrejugadors, Jugador Jugadors[]){
    //Pre: El nombre de jugadors de la partida
    //Post: Escriu en pantalla el jugador que ha guanyat
    Jugador temp[MIDA_MAXIMA];
    Ordenar_Ranking(nombrejugadors,Jugadors,temp);
    cout<<"GUANYADOR: JUGADOR "<<temp[1].lletra<<endl;
}

void Escriure_Controlador(int files, int columnes, char tauler[][MIDA_MAXIMA]){
    bool trobat=false,lletraset,possible=false;
    char lletra;
    int i=2,j,resultat;
    while(i<files+2 and !trobat){
        lletraset=false;
        possible=true;
        j=2;
        while(j<columnes+2 and possible){
            if(tauler[j][i]==' ')possible=false;
            if(!lletraset){
                if(tauler[j][i]!=' ' and tauler[j][i]!='#'){
                    lletra=tauler[j][i];
                    lletraset=true;
                }
            }
            else if(tauler[j][i]!='#' and tauler[j][i]!=lletra)
                possible=false;
            j++;
        }
        if(possible)trobat=true;
        i++;
    }
    if(trobat)cout<<"EL JUGADOR "<<lletra<<" CONTROLA LA FILA "<<char(i-3+'a')<<endl;
    else{
        i=2;
        while(i<columnes+2 and !trobat){
            lletraset=false;
            possible=true;
            j=2;
            while(j<files+2 and possible){
                if(tauler[i][j]==' ')possible=false;
                if(!lletraset){
                    if(tauler[i][j]!=' ' and tauler[i][j]!='#'){
                        lletra=tauler[i][j];
                        lletraset=true;
                    }
                }
                else if(tauler[i][j]!='#' and tauler[i][j]!=lletra)
                    possible=false;
                j++;
            }
            if(possible)trobat=true;
            i++;
        }
        if(trobat)cout<<"EL JUGADOR "<<lletra<<" CONTROLA LA COLUMNA "<<char(i-3+'a')<<endl;
        else cout<<"CAP JUGADOR CONTROLA CAP FILA NI COLUMNA"<<endl;
    }
}

int main()
{
    //Entrada: El nom d'un fitxer de tauler correcte que es trobi al mateix directori,
    //el numero de jugadors que participar�n a la partida i la posici� on posar� l'ex�rcit cadasc�n
    //Sortida: La taula i la llista de jugadors ordenats per assoliments despr�s de cada entrada
    int files, columnes, nombrejugadors=0, torn=1;
    Jugador Jugadors[JUGADORS_MAX];
    char tauler[MIDA_MAXIMA][MIDA_MAXIMA], exercit_mayus, fila, columna, fila_in, columna_in;
    string nomarxiu="tauler5x6Bis.txt";
    fstream fitxer;

    cout<<"BENVINGUTS A OKUPACIO !"<<endl;
    while(nombrejugadors<2 or nombrejugadors>10){
        cout<<"ENTRA NOMBRE DE JUGADORS (2..10):"<<endl;
        cin>>nombrejugadors;
    }
    cout<<"NOM DEL FITXER DEL TAULER:"<<endl;
    cin>>nomarxiu;
    fitxer.open(nomarxiu.c_str(),fstream::in);
    if (fitxer.is_open()){
        fitxer>>files>>columnes;
        Netejar_tauler(tauler);
        Inicialitzar_Tupla(nombrejugadors,Jugadors);
        Fer_Contorn(files,columnes,tauler);
        Posar_Murs(columnes,fitxer,tauler);
        Dibuixar_Tauler(files,columnes,tauler);
        while(!EsPle(files,columnes,tauler) and torn!=-1){
            exercit_mayus=torn+'A'-1; //=equips[torn].lletra;
            do{
                cout<<"JUGADOR "<<exercit_mayus<<endl;
                cin>>fila_in>>columna_in;
            }
            while(!Entrada_Correcta(fila_in,columna_in,files,columnes,tauler));
            fila=fila_in-'a'+2; columna=columna_in-'a'+2;
            if(fila_in=='0' and columna_in=='0'){
                Jugadors[torn].actiu=false;
                Esborrar_Exercit(files,columnes,exercit_mayus,tauler);
            }
            else if(tauler[columna][fila]==' '){
                tauler[columna][fila]=exercit_mayus;
                Jugadors[torn].caselles++;
                Tractar_Adjacents(fila,columna,Jugadors,torn,tauler);
            }
            Actualitzar_Temps(torn,nombrejugadors,Jugadors);
            Dibuixar_Tauler(files,columnes,tauler);
            Escriure_Ranking(nombrejugadors,Jugadors);
            if(Jugadors_Actius(Jugadors,nombrejugadors)>1)
                torn=Buscar_Proper_Torn(nombrejugadors,torn,Jugadors);
            else torn=-1;
        }
        cout<<"GAME OVER"<<endl<<endl;
        Escriure_Guanyador(nombrejugadors,Jugadors);
        Escriure_Controlador(files,columnes,tauler);
    }
    else cout<<"NO ES POT OBRIR EL FITXER"<<endl;
    return 0;
}
