var searchData=
[
  ['inicialitzar_5fvorac',['Inicialitzar_vorac',['../class_solucio.html#a7c92af0243ab4aaabf78432a6246fd4b',1,'Solucio']]]
];
