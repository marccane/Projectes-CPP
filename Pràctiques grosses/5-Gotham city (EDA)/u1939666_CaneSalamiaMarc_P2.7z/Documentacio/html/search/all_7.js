var searchData=
[
  ['mostrar',['mostrar',['../class_solucio.html#aceda78a3c2cfee7f456c8d10e80a3e49',1,'Solucio']]]
];
