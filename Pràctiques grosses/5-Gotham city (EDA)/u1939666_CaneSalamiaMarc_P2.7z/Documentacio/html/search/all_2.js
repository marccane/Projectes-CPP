var searchData=
[
  ['candidat',['Candidat',['../class_candidat.html',1,'Candidat'],['../class_candidat.html#a2de8bc5d7c152b6c518976f98691ee58',1,'Candidat::Candidat()']]],
  ['completa',['completa',['../class_solucio.html#adf12823d6437ac4bb638c9f27caf1078',1,'Solucio']]]
];
