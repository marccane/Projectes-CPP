var searchData=
[
  ['dades_5faresta',['Dades_aresta',['../class_graf_v_map.html#a66c08b1fc6e22bba8752053610e0a9d1',1,'GrafVMap']]],
  ['desanotar',['desanotar',['../class_solucio.html#aa445016e6ec63ad5c310b6690c4654fd',1,'Solucio']]]
];
