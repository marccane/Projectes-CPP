var searchData=
[
  ['acceptable',['acceptable',['../class_solucio.html#acda8381499ec8da73d50f469ac6a0271',1,'Solucio']]],
  ['actual',['actual',['../class_candidat.html#a765a45373458000b24d2397a49b00661',1,'Candidat']]],
  ['afegir_5fcandidat',['Afegir_Candidat',['../class_solucio.html#ae27e44da187832c63d13fafbad99338a',1,'Solucio']]],
  ['afegiraresta',['AfegirAresta',['../class_graf_v_map.html#a9637af4ce87d856cf5e92499f2148c05',1,'GrafVMap']]],
  ['anotar',['anotar',['../class_solucio.html#a7f6ce6144da2c095fc7229840833de55',1,'Solucio']]],
  ['aresta',['aresta',['../structaresta.html',1,'']]]
];
