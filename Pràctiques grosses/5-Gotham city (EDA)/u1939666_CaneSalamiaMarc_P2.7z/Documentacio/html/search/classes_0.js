var searchData=
[
  ['aresta',['aresta',['../structaresta.html',1,'']]]
];
