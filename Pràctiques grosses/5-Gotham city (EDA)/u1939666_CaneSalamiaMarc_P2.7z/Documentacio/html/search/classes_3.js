var searchData=
[
  ['solucio',['Solucio',['../class_solucio.html',1,'']]],
  ['solucionador',['Solucionador',['../class_solucionador.html',1,'']]]
];
