var searchData=
[
  ['get_5fnvertex',['Get_nvertex',['../class_solucio.html#a30d3958b28793eee3743a17992913129',1,'Solucio']]],
  ['grafvmap',['GrafVMap',['../class_graf_v_map.html',1,'GrafVMap'],['../class_graf_v_map.html#aa2e665857b629cc26f642913737da444',1,'GrafVMap::GrafVMap(int nVertexs=MIDA_DEFECTE, bool dirigit=false)'],['../class_graf_v_map.html#ab7075c278d693a806489ad15effb7c5f',1,'GrafVMap::GrafVMap(const char *nomFitxerTGF, bool dirigit=false)']]]
];
