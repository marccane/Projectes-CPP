var searchData=
[
  ['seguent',['seguent',['../class_candidat.html#af9da25394461e5e8c4708306322bd958',1,'Candidat']]],
  ['solucio',['Solucio',['../class_solucio.html',1,'Solucio'],['../class_solucio.html#a62b21c676a5a87fc28cc2652b59ffc07',1,'Solucio::Solucio()']]],
  ['solucionador',['Solucionador',['../class_solucionador.html',1,'']]],
  ['solucionar',['Solucionar',['../class_solucionador.html#a14409145948163d314fac6c5bae39fa2',1,'Solucionador']]],
  ['solucionaroptim',['SolucionarOptim',['../class_solucionador.html#a38f88b117e2de50c1f18387024309919',1,'Solucionador']]],
  ['solucionarvorac',['SolucionarVorac',['../class_solucionador.html#ade5f99b343e69f4f0f51f00c74383c68',1,'Solucionador']]]
];
