var searchData=
[
  ['buscar_5fprometedor',['Buscar_Prometedor',['../class_solucio.html#afcef66048c69d86a2f269f2690243ddc',1,'Solucio']]]
];
