var searchData=
[
  ['transformar_5fvertex',['Transformar_vertex',['../class_graf_v_map.html#a6c7af4a43ffee6aeea905aef4c586525',1,'GrafVMap']]],
  ['trobarmillor',['trobarMillor',['../class_solucionador.html#ab74a277face60bb4a4f71e9f701fc7b6',1,'Solucionador']]],
  ['trobarunasolucio',['trobarUnaSolucio',['../class_solucionador.html#afc87e504146ccfb78fd74aaf65e3b7ff',1,'Solucionador']]]
];
