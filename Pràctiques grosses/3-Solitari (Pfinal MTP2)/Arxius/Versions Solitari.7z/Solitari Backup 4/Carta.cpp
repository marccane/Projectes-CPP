#include "Carta.h"
#include <iostream>

using namespace std;

Carta::Carta()
{
    a_oberta=false;
    //a_oberta=true;
}

void Carta::Modificar(char valor, char pal){
    a_valor=valor;
    a_pal=pal;
}

void Carta::Intercanviar(Carta &b){
    Carta temp=b;
    b=*this;
    *this=temp;
}

bool Carta::esnegra(){
    return a_pal=='P' or a_pal=='T';
}

bool Carta::esoberta(){
    return a_oberta;
}

void Carta::Set_obrir(bool obrir){
    a_oberta=obrir;
}

void Carta::mostrar(){
    if(a_oberta)cout<<a_valor<<a_pal<<" ";
    else cout<<"** ";
}

bool Carta::Casen(Carta a){ //Grossa.casa(petita)=true
    char tempchar='1', vecvalors[13];
    for(int i=0;i<=9;i++){
        vecvalors[i]=tempchar;
        tempchar++;
    }
    vecvalors[0]='A';
    vecvalors[9]='D';
    vecvalors[10]='J';
    vecvalors[11]='Q';
    vecvalors[12]='K';
    bool cas=false;
    int index=0, index2=0; //petita =2 , grossa =1
    if(a.esnegra()!=esnegra()){
        for(int i=0;i<=12;i++){
            //cout<<a_valor<<" "<<a.a_valor<<" i="<<i<<endl;
            if(a_valor==vecvalors[i])index=i;
            if(a.a_valor==vecvalors[i])index2=i;
        }
        if(index-1==index2)cas=true;
        //cout<<"index="<<index<<" index2="<<index2<<endl;
    }
    //cout<<(cas?"lescartes casen":"no casen")<<endl;
    return cas;
}

bool Carta::EsRei(){
    return a_valor=='K';
}
