#ifndef TAULER_H
#define TAULER_H
#include "Carta.h"
#include "PilaCartes.h"
#include "Baralla.h"
//#define private public
class Tauler
{
    public:
        Tauler();
        void repartir(Baralla);
        void mostrar();
        void Inserir_Carta_Tauler(int col);
        Carta Get_Carta_Tauler(int col);
        void Inserir_Carta_Tauler(Carta inserir, int col);
        //void Afegir_mida(int col, int mida);
    private:
        //METODES PRIVATS
        int FilesMaximes();
        //ATRIBUTS
        Carta **a_mat;
        int a_n, *a_mida; //Tauler din�mic
};

#endif // TAULER_H
