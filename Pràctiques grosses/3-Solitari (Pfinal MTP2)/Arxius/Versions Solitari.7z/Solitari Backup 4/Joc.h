#ifndef JOC_H
#define JOC_H
#include "PilaCartes.h"
#include "Tauler.h"
#include "Carta.h"
#include "Baralla.h"
//#define private public

class Joc
{
    public:
        Joc(Baralla);
        void mostrar();
        void Jugar();

    private:
        //FUNCIONS:
        void emplenar_ma(Baralla);
        void MostrarMenu();
        void TriarOpcio();
        int Demanar_columna();
        int Demanar_Fila();
        void Demanar_origen(int &col, int &fila);
        bool PosarAlTauler(Carta car, int col);
        void Mostrar_Cim_Pila(const PilaCartes &pila);
        bool Partida_Guanyada();

        //ATRIBUTS:
        int a_opcio;
        bool a_guanyada;
        PilaCartes a_ma, a_descartades, a_pals[4];
        Tauler a_tauler;
};

#endif // JOC_H
