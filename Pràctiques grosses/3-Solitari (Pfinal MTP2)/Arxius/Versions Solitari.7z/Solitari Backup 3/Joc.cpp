#include <iostream>
#include "Joc.h"
#include "PilaCartes.h"
#include "Tauler.h"
#include "Carta.h"

using namespace std;

Joc::Joc(Baralla a)
{
    const char tempals[]={'P','c','d','T'};
    for(int i=0;i<4;i++)a_pals[i].Set_Coll(tempals[i]);
    a_guanyada=false;
    a_tauler.repartir(a);
    //cout<<"gaben pls: ";a_tauler.a_mat[4][4].mostrar();
    //cout<<endl;
    emplenar_ma(a);
}

void Joc::MostrarMenu(){
    cout<<"MENU"<<endl<<
    "1. OBRIR UNA CARTA (O TORNAR A COMENCAR)"<<endl<<
    "2. POSAR UNA CARTA (MA->TAULER)"<<endl<<
    "3. POSAR UNA CARTA (MA->PILA)"<<endl<<
    "4. MOURE UNA CARTA (TAULER->TAULER)"<<endl<<
    "5. MOURE UNA CARTA (TAULER->PILA)"<<endl<<
    "6. RECUPERAR UNA CARTA (PILA->TAULER)"<<endl<<
    "9. MOSTRAR MENU"<<endl<<
    "0. ABANDONAR LA PARTIDA"<<endl;
}

void Joc::TriarOpcio(){
    cout<<"OPCIO: ";
    cin>>a_opcio;
}

void Joc::mostrar(){
    cout<<"ESTAT DEL JOC"<<endl;
    for(int i=0;i<4;i++){
        if(!a_pals[i].buida())
            a_pals[i].cim().mostrar();
        else cout<<"   ";
    }
    cout<<"   ";
    if(a_ma.buida())cout<<"   ";
    else a_ma.cim().mostrar();
    if(a_descartades.buida())cout<<"   ";
    else a_descartades.cim().mostrar();
    cout<<endl;
    for(int i=1;i<=7;i++)cout<<"c"<<i<<" ";
    cout<<endl;
    a_tauler.mostrar();
}

void Joc::emplenar_ma(Baralla bar){
    for(int i=22;i>=0;i--) //!not sure about RES
        a_ma.empila(bar.Get_Carta(i));
}

void Joc::Jugar(){
    int fila, col;
    cout<<"gaben pls: ";a_tauler.a_mat[4][4].mostrar();
    cout<<endl;
    while(a_opcio!=0 and !a_guanyada){
        TriarOpcio();
        switch(a_opcio){
        case 0: break;
        case 1:
            if(a_ma.buida() and !a_descartades.buida())
                a_descartades.Girar_Cartes(a_ma);
            else if(!a_ma.buida()){
                Carta temp;
                //cout<<"PRINCIPI:"<<a_ma.cim().esoberta()<<endl;
                temp=a_ma.cim();
                temp.Set_obrir(true);
                a_ma.desempila();
                //a_ma.empila(temp);
                //cout<<"SEGONA:"<<a_ma.cim().esoberta()<<endl;
                //a_ma.cim().Set_obrir(true);
                a_descartades.empila(temp);
                //a_descartades.cim().Set_obrir(true);
                a_ma.desempila();
            }
            mostrar();
            break;
        case 2:
            if(!a_descartades.buida()){
                col=Demanar_columna();
                if(PosarAlTauler(a_descartades.cim(),col)){
                    a_descartades.desempila();
                }
                else cout<<"LA CARTA NO ES POT POSAR A LA COLUMNA "<<col<<endl;
            }
            else cout<<"NO HI HA CAP CARTA PER AGAFAR"<<endl;
            mostrar();
            break;
        case 3:

            mostrar();
            break;
        case 4:

            mostrar();
            break;
        case 5:

            mostrar();
            break;
        case 6:

            mostrar();
            break;
        case 9: MostrarMenu(); break;
        default:
            cout<<"OPCIO NO DEFINIDA"<<endl;
            break;
        }
    }
    //cout<<a_guanyada?"PARTIDA GUANYADA":"PARTIDA ABANDONADA"<<endl;
}

int Joc::Demanar_columna(){
    int col;
    cout<<"A QUINA COLUMNA LA VOLS POSAR:"<<endl;
    cin>>col;
    return col;
}

void Joc::Demanar_origen(int &col, int &fila){
    cout<<"ENTRA LA COLUMNA ORIGEN I LA FILA ORIGEN:"<<endl;
    cin>>col>>fila;
}

bool Joc::PosarAlTauler(Carta car, int col){
    bool HaSigutPossible=true;
    if(col<=7 and col>=0){
        if(!a_tauler.Get_Carta_Tauler(col).Casen(car)) //Comprova si es pot posra i la posa si es pot
            HaSigutPossible=false;
    }
    else HaSigutPossible=false;
    return HaSigutPossible;
}
