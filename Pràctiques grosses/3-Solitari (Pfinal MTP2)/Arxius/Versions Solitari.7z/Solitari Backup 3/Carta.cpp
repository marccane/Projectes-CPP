#include "Carta.h"
#include <iostream>

using namespace std;

Carta::Carta()
{
    a_oberta=false;
    a_oberta=true;
}

void Carta::Modificar(char valor, char pal){
    a_valor=valor;
    a_pal=pal;
}

void Carta::Intercanviar(Carta &b){
    Carta temp=b;
    b=*this;
    *this=temp;
}

bool Carta::esnegra(){
    return a_pal=='P' or a_pal=='T';
}

bool Carta::esoberta(){
    return a_oberta;
}

void Carta::Set_obrir(bool obrir){
    a_oberta=obrir;
}

void Carta::mostrar(){
    if(a_oberta)cout<<a_valor<<a_pal<<" ";
    else cout<<"** ";
}

/*!
bool Casen(Carta a, Carta b){ //la de la dreta �s la que anir� a sota
    char tempchar='1', vecvalors[13];
    for(int i=0;i<=9;i++){
        vecvalors[i]=tempchar;
        tempchar++;
    }
    vecvalors[0]='A';
    vecvalors[9]='D';
    vecvalors[10]='J';
    vecvalors[11]='Q';
    vecvalors[12]='K';
    bool cas=false;
    int index=0, index2=0;
    if(a.esnegra()!=b.esnegra()){
        for(int i=0;i<=12;i++){
            if(a.a_valor==vecvalors[i])index=i;
            if(b.a_valor==vecvalors[i])index2=i;
        }
        if(index-1==index2)cas=true;
    }
    return cas;
}*/

bool Carta::Casen(Carta a){ //Grossa.casa(petita)=true
    char tempchar='1', vecvalors[13];
    for(int i=0;i<=9;i++){
        vecvalors[i]=tempchar;
        tempchar++;
    }
    vecvalors[0]='A';
    vecvalors[9]='D';
    vecvalors[10]='J';
    vecvalors[11]='Q';
    vecvalors[12]='K';
    bool cas=false;
    int index=0, index2=0; //petita =1 , grossa =2
    if(a.esnegra()!=esnegra()){
        for(int i=0;i<=12;i++){
            if(a.a_valor==vecvalors[i])index=i;
            if(a_valor==vecvalors[i])index2=i;
        }
        if(index-1==index2)cas=true;
    }
    return cas;
}

