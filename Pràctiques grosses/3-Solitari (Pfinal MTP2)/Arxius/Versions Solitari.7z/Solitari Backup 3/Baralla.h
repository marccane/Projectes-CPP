#ifndef BARALLA_H
#define BARALLA_H
#include "Carta.h"
#define private public

class Baralla
{
    public:
        Baralla();
		Baralla(int llavor, int passos);
        Carta Get_Carta(int index);
    private:
        static void iniLlavor(int llavor);
        static int aleatori(int max);
        // FALTEN ELS ATRIBUTS NORMALS
        Carta a_baralla[52];
        // atribut de classe
        static unsigned a_llavor;
};

#endif // BARRALLA_H
