#include "Tauler.h"
#include "Baralla.h"
#include <iostream>

using namespace std;

Tauler::Tauler()
{
    a_n=7;
    a_mida=new int[a_n];
    a_mat=new Carta*[a_n];
    for(int i=0;i<a_n;i++){
        a_mat[i]=new Carta[13+i];
    }
}

void Tauler::repartir(Baralla bar){
    int comptador=51;
    for(int i=0;i<a_n;i++){
        //for(int j=0;j<=i;j++){
        for(int j=i;j<a_n;j++){
            a_mat[j][i]=bar.Get_Carta(comptador);
            comptador--;
            if(i==j){
                a_mat[i][j].Set_obrir(true);
                a_mida[i]=j+1;
            }
        }
    }
}

void Tauler::mostrar(){
    int numfila=1, maxfiles;
    cout<<a_mida[0]<<"mida"<<endl;
    for(int i=0;i<7;i++){ //!NO SER� SEMPRE 7!!! Buscar el maxim de files*
        for(int j=0;j<a_n;j++){
            if(i<a_mida[j]){a_mat[j][i].mostrar();//!Diria que �s aixi
            }
            else cout<<"   ";
        }
        cout<<'f'<<numfila<<endl;
        numfila++;
    }
}

void Tauler::Inserir_Carta_Tauler(Carta inserir, int col){
    a_mat[col][a_mida[col]+1]=inserir;
    a_mida[col]++;
}

Carta Tauler::Get_Carta_Tauler(int col){
    return a_mat[col][a_mida[col]];
}
