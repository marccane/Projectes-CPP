#include <iostream>
#include "Baralla.h"
#include "Joc.h"

using namespace std;

//for(int i=0;i<13;i++)cout<<vecvalors[i]<<endl;
/*char vec[13];
CrearVectorValors(vec);
return 0;*/

void llegirValors(int &llavor, int &passos){
    cout<<"ENTRA LA LLAVOR:"<<endl;
    cin>>llavor;
    cout<<"ENTRA ELS PASSOS:"<<endl;
    cin>>passos;
}

int main(){
    int llavor, passos;
    llegirValors(llavor, passos);
    Baralla baralla(llavor, passos);
    Joc joc(baralla);
    joc.Jugar();
    return 0;
}
