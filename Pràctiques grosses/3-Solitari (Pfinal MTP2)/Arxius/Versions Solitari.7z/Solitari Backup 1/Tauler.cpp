#include "Tauler.h"
#include "Baralla.h"
#include <iostream>

using namespace std;

Tauler::Tauler()
{
    //ctor
}

void Tauler::repartir(Baralla bar){
    int comptador=0;
    for(int i=0;i<7;i++){
        for(int j=0;j<=i;j++){
            a_tauler[i][j]=bar.Get_Carta(comptador);
            comptador++;
            if(i==j)a_tauler[i][j].Set_obrir(true); //es pot fer m�s macu
        }
    }
}

void Tauler::mostrar(){
    int numfila=1;
    for(int i=0;i<=7;i++){
        for(int j=0;j<7;j++){
            if(i<=j)a_tauler[i][j].mostrar(); //TEMPORAL
            else cout<<"   ";
        }
        cout<<'f'<<numfila<<endl;
        numfila++;
    }
}
