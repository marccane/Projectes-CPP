#include <iostream>
#include "Joc.h"
#include "PilaCartes.h"
#include "Tauler.h"
#include "Carta.h"

using namespace std;

Joc::Joc()
{
    //ctor
}

Joc::Joc(Baralla a)
{
    a_tauler.repartir(a);
    emplenar_ma(a);
}

void Joc::MostrarMenu(){
    cout<<"MENU"<<endl<<
    "1. OBRIR UNA CARTA (O TORNAR A COMENCAR)"<<endl<<
    "2. POSAR UNA CARTA (MA->TAULER)"<<endl<<
    "3. POSAR UNA CARTA (MA->PILA)"<<endl<<
    "4. MOURE UNA CARTA (TAULER->TAULER)"<<endl<<
    "5. MOURE UNA CARTA (TAULER->PILA)"<<endl<<
    "6. RECUPERAR UNA CARTA (PILA->TAULER)"<<endl<<
    "9. MOSTRAR MENU"<<endl<<
    "0. ABANDONAR LA PARTIDA"<<endl;
}

void Joc::TriarOpcio(){
    cout<<"OPCIO: ";
    cin>>a_opcio;
}

void Joc::mostrar(){
    cout<<"ESTAT DEL JOC"<<endl;
    for(int i=1;i<=7;i++)cout<<"c"<<i<<" ";
    cout<<endl;
    a_tauler.mostrar(); //temporal
}

void Joc::emplenar_ma(Baralla bar){
    for(int i=23;i<52;i++) //not sure about 23
        a_ma.empila(bar.Get_Carta(i));
}
