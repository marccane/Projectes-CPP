#ifndef TAULER_H
#define TAULER_H
#include "Carta.h"
#include "PilaCartes.h"
#include "Baralla.h"
class Tauler
{
    public:
        Tauler();
        void repartir(Baralla);
        void mostrar();
    private:
        Carta a_tauler[7][19]; //noms iguals //Qu� �s aixo de que va de costat? amb la est�tica no no?
        //int a_n, a_mida[19]; //Tauler din�mic
};

#endif // TAULER_H
