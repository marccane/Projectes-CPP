#include "Carta.h"
#include <iostream>

using namespace std;

Carta::Carta()
{
    a_oberta=false;
}

void Carta::Modificar(char valor, char pal){
    a_valor=valor;
    a_pal=pal;
}

void Carta::Intercanviar(Carta &b){
    Carta temp=*this;
    *this=b;
    b=temp;
}

bool Carta::esnegra(){
    return a_pal=='P' or a_pal=='T';
}

bool Carta::esoberta(){
    return a_oberta;
}

void Carta::Set_obrir(bool obrir){
    a_oberta=obrir;
}

void Carta::mostrar(){
    if(a_oberta)cout<<a_valor<<a_pal<<" ";
    else cout<<"** ";
}
