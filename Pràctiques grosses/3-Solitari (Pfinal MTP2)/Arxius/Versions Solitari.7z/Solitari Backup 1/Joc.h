#ifndef JOC_H
#define JOC_H
#include "PilaCartes.h"
#include "Tauler.h"
#include "Carta.h"
#include "Baralla.h"

class Joc
{
    public:
        Joc();
        Joc(Baralla);
        void MostrarMenu();
        void TriarOpcio();
        void mostrar();

    private:
        //FUNCIONS:
        void emplenar_ma(Baralla);
        //ATRIBUTS:
        int a_opcio;
        PilaCartes a_ma, a_descartades, a_pals[4];
        Tauler a_tauler; //noms iguals
};

#endif // JOC_H
