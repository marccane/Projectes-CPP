#ifndef CARTA_H
#define CARTA_H

class Carta
{
    public:
        Carta();
        void Modificar(char valor, char pal);
        void Intercanviar(Carta &b);
        bool esnegra();
        bool esoberta();
        void Set_obrir(bool obrir);
        void mostrar();
    private:
        char a_valor, a_pal;
        bool a_oberta;
};

#endif // CARTA_H
