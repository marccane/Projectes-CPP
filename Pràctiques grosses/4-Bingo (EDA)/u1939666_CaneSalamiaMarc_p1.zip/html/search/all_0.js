var searchData=
[
  ['afegir',['Afegir',['../class_contenidor.html#a7bd6e01319371a999154beb58e719085',1,'Contenidor::Afegir(const triplet &amp;)'],['../class_contenidor.html#a7bd6e01319371a999154beb58e719085',1,'Contenidor::Afegir(const triplet &amp;)'],['../class_contenidor.html#a7bd6e01319371a999154beb58e719085',1,'Contenidor::Afegir(const triplet &amp;)']]]
];
