var searchData=
[
  ['existeix',['Existeix',['../class_contenidor.html#ab1df6731a4b2f8b6d357a07a4d844157',1,'Contenidor::Existeix(const triplet &amp;)'],['../class_contenidor.html#ab1df6731a4b2f8b6d357a07a4d844157',1,'Contenidor::Existeix(const triplet &amp;)'],['../class_contenidor.html#ab1df6731a4b2f8b6d357a07a4d844157',1,'Contenidor::Existeix(const triplet &amp;)']]]
];
